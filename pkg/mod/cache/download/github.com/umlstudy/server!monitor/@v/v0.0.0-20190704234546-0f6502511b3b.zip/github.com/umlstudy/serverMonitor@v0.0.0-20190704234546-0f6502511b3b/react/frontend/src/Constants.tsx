
export const GATEWAY_URL = 'http://localhost:7007/getServerInfos';

export const GRAHP_VALUES_CNT:number = 50;
