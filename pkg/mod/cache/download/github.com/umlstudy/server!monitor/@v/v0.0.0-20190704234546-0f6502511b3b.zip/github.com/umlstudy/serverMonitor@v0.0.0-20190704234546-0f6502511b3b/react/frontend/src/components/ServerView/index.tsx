import ServerView from './presenter';

// const mapStateToProps = (globalState: GlobalState) => {
//     return {
//         num: globalState.reducer.num,
//     };
// };

// const mapDispatchProps = (dispatch: any) => {
//     return {
//         handleDecrement: () => { dispatch(counter.decrement()) },
//         handleIncrement: () => { dispatch(counter.increment()) },
//     };
// };

// export default connect(mapStateToProps, mapDispatchProps)(ServerView);

export default ServerView;
