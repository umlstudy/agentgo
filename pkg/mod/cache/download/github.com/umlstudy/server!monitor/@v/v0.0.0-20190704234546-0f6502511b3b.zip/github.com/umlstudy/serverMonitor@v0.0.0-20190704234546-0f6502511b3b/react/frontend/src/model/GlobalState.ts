
// tslint:disable-next-line:interface-name
export default interface GlobalState {
    reducer:any
}