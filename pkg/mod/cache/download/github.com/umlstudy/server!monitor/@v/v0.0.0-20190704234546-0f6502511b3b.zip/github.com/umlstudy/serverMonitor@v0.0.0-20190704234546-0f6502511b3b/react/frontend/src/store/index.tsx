import configure from './configure';
export default configure();