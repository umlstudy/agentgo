import { combineReducers } from 'redux';
import counter from './reducer';

export default combineReducers({
    reducer:counter
});